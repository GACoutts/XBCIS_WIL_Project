import CDashboard from './CDashboard.jsx';

function App() {
  return(
    <>
    <CDashboard/>
    </>
  );
}

export default App
